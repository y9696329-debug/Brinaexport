extends Node



var nodes_list = [
	"player3d", "zombie", "car", "gun", "lava", "coin", "portal", "boss",
	"wall", "floor", "box", "water", "tree", "house", "light_sun","sky","camera2D",
	"button_kill", "joystick", "healthbar", "text_score", "camera_follow","button","textshow","text","Ui3d","ui2D","Ui"

]

# الدالة اللي تبيها انت
func Add_new(type: String, id: String = ""):
	if id == "": id = type + "_" + str(randi()%999)
	
	var node = Button.new() # كلهم .new
	node.name = id
	node.text = type
	node.position = Vector2(200,200)
	node.size = Vector2(120,40)
	
	get_tree().current_scene.add_child(node)
	
	# حفظ تلقائي
	save_project(type, id, node.position)
	
	print('Brina.Add.new("%s") تم' % type)
	return node

func save_project(type, id, pos):
	var file = FileAccess.open("user://brina_save.json", FileAccess.WRITE)
	file.store_string(JSON.stringify({"type":type,"id":id,"x":pos.x,"y":pos.y}))

func load_project():
	if not FileAccess.file_exists("user://brina_save.json"): return
	var data = JSON.parse_string(FileAccess.open("user://brina_save.json", FileAccess.READ).get_as_text())
	Add_new(data["type"], data["id"])
