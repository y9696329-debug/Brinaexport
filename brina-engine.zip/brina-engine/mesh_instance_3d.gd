extends MeshInstance3D

@export var size: int = 1000
@export var divisions: int = 1000

func _ready():
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_LINES)
	
	var half = size / 2.0
	
	for i in range(divisions + 1):
		var pos = -half + i * (size / float(divisions))

		st.add_vertex(Vector3(pos, 0, -half))
		st.add_vertex(Vector3(pos, 0, half))
		
		st.add_vertex(Vector3(-half, 0, pos))
		st.add_vertex(Vector3(half, 0, pos))
	
	mesh = st.commit()
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(1, 1, 1, 0.15)
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material_override = mat
