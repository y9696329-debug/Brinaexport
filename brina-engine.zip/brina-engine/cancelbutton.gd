extends Button
const NEXT_SCENE = "res://mainometan.tscn"
func _ready() -> void:
		pressed.connect(_on_pressed)
func _on_pressed() -> void:
				get_tree().change_scene_to_file(NEXT_SCENE)
				
