extends Camera3D

@export var sensitivity: float = 0.3
@export var min_pitch: float = -60.0
@export var max_pitch: float = 80.0
@export var min_distance: float = 0.8

var yaw: float = 0.0
var pitch: float = 0.0
var player: CharacterBody3D

var default_distance: float
var height_offset: float
var raycast: RayCast3D

func _ready():
	near = 0.001
	player = get_parent() as CharacterBody3D
	
	if player:
		var initial_offset = global_position - player.global_position
		height_offset = initial_offset.y
		default_distance = Vector2(initial_offset.x, initial_offset.z).length()
		
		raycast = RayCast3D.new()
		player.add_child.call_deferred(raycast)
		raycast.enabled = true
		raycast.exclude_parent = true

	top_level = true

func _unhandled_input(event):
	if event is InputEventScreenDrag or (event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)):
		yaw -= event.relative.x * sensitivity
		pitch += event.relative.y * sensitivity
		pitch = clamp(pitch, min_pitch, max_pitch)

func _process(_delta):
	if not player:
		return
	
	var yaw_rad = deg_to_rad(yaw)
	var pitch_rad = deg_to_rad(pitch)
	
	var target = player.global_position + Vector3(0, height_offset, 0)
	var current_distance = default_distance
	
	var dir = Vector3(
		sin(yaw_rad) * cos(pitch_rad),
		sin(pitch_rad),
		cos(yaw_rad) * cos(pitch_rad)
	).normalized()
	
	if is_instance_valid(raycast):
		raycast.global_position = target
		raycast.target_position = dir * default_distance
		raycast.force_raycast_update()
		
		if raycast.is_colliding():
			var hit_point = raycast.get_collision_point()
			current_distance = target.distance_to(hit_point) - 0.1
	
	current_distance = max(current_distance, min_distance)
		
	global_position = target + (dir * current_distance)
	look_at(target, Vector3.UP)
