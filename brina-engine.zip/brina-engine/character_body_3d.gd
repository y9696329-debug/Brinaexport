extends CharacterBody3D
const SPEED = 10.0
const FLY_SPEED = 8.0
@onready var camera: Camera3D = $cam
func _physics_process(delta: float) -> void:
	var vertical_input := 0.0
	if Input.is_action_pressed("ui_accept"):
		vertical_input += 1.0
	if Input.is_action_pressed("ui_cancel") or Input.is_physical_key_pressed(KEY_SHIFT):
		vertical_input -= 1.0
	var input_dir := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var direction := Vector3.ZERO
	if is_instance_valid(camera):
		var cam_basis = camera.global_transform.basis
		var forward = -cam_basis.z
		var right = cam_basis.x
		forward = forward.normalized()
		right = right.normalized()
		direction = (right * input_dir.x - forward * input_dir.y)
	if direction != Vector3.ZERO:
		direction = direction.normalized()
		velocity.x = direction.x * SPEED
		velocity.z = direction.z * SPEED
		velocity.y = direction.y * SPEED + (vertical_input * FLY_SPEED)
		var flat_dir = Vector3(direction.x, 0, direction.z)
		if flat_dir.length() > 0.1:
			var target_rotation = atan2(flat_dir.x, flat_dir.z)
			rotation.y = lerp_angle(rotation.y, target_rotation, delta * 10.0)
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		velocity.z = move_toward(velocity.z, 0, SPEED)
		velocity.y = vertical_input * FLY_SPEED
	move_and_slide()
